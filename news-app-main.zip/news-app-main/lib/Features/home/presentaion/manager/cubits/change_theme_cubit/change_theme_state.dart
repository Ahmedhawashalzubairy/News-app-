class ChangeThemeState {}

class ChangeThemeInitial extends ChangeThemeState {}

class ChangeThemeDone extends ChangeThemeState {}
