class CategoryData {
  final String text;
  final String image;

  CategoryData({required this.text, required this.image});
}
