import '../models/category_data.dart';

List<CategoryData> categoryDataList = [
  CategoryData(
    image: 'assets/business.avif',
    text: 'business',
  ),
  CategoryData(
    image: 'assets/entertaiment.avif',
    text: 'entertainment',
  ),
  CategoryData(
    image: 'assets/health.avif',
    text: 'health',
  ),
  CategoryData(
    image: 'assets/science.avif',
    text: 'science',
  ),
  CategoryData(
    image: 'assets/sports.avif',
    text: 'sports',
  ),
  CategoryData(
    image: 'assets/technology.jpeg',
    text: 'technology',
  ),
];
